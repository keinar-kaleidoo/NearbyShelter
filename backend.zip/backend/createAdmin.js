const mongoose = require('mongoose');
const Admin = require('./models/admin');
const bcrypt = require('bcryptjs');
require('dotenv').config();

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.log('MongoDB connection error:', err));

async function createAdmin() {
  const username = 'keinarelkayam';
  const password = 'K305541153e!';

  const hashedPassword = await bcrypt.hash(password, 10);
  console.log('Original password:', password);
  console.log('Hashed password:', hashedPassword);

  const admin = new Admin({
    username,
    password: hashedPassword
  });

  await admin.save();
  console.log('Admin created successfully with encryption');
}

createAdmin();
